import React from 'react';
import './App.css';
import Parent from "./modul3/Parent";

class App extends React.Component {
  render() {
    return (
      <div className="App">
        <h2>Kelompok 16</h2>
        <Parent />
      </div>
    )
  }
}

export default App;